from pyspark.sql import SparkSession
from pyspark import SparkFiles

# Pyspark session
spark = SparkSession.builder.appName("csv").master("spark://spark:7077").getOrCreate() #

# Read the csv file, try to infer the schema
df = spark.read.option("header", True).csv("./walmart_stock-1.csv", inferSchema=True )

#df.printSchema()
#df.show()

# Stop
spark.sparkContext.stop()