from pyspark.sql import SparkSession
from pyspark import SparkFiles
from pyspark import SparkContext

# Pyspark session
spark = SparkSession.builder.appName("csv").master("spark://spark:7077").getOrCreate() #
spark.sparkContext.addFile("./walmart_stock-1.csv")

#print(SparkFiles.get("walmart_stock-1.csv"))

print("Testing Testing")

# Read the csv file, try to infer the schema
df = spark.read.option("header", True).csv("local:/walmart_stock-1.csv", inferSchema=True )
df.printSchema()
df.show()

#df.write.csv("/home/jovyan/Spark/test.csv")

# Stop
#spark.sparkContext.stop()